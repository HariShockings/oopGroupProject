package Views;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.table.DefaultTableModel;
import Controllers.SupplierController;
import Models.Supplier;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.List;

public class SupplierView extends javax.swing.JFrame {

    Supplier objSupplier;
    SupplierController supplierController;
    DefaultTableModel tableModel;
    JTable tableSuppliers;

    public SupplierView() {
        initComponents();
        supplierController = new SupplierController();
        tableModel = new DefaultTableModel();
        tableModel.addColumn("Supplier ID");
        tableModel.addColumn("Supplier Name");
        tableSuppliers = new JTable(tableModel); // Using the existing tableSuppliers variable
        jScrollPane2.setViewportView(tableSuppliers);
        refreshSupplierTable();
    }

    private void initComponents() {
        jPanel1 = new javax.swing.JPanel();
        btnManageOrders = new javax.swing.JButton();
        btnManageSuppliers = new javax.swing.JButton();
        btnManageEmployees = new javax.swing.JButton();
        btnManageProducts = new javax.swing.JButton();
        btnManageMaterials = new javax.swing.JButton();
        btnAllocateE2O = new javax.swing.JButton();
        btnMonthlyIncomeExpenseReport = new javax.swing.JButton();
        btnLogout = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jLabelSupplierID = new javax.swing.JLabel();
        jLabelSupplierName = new javax.swing.JLabel();
        jLabelContactNumber = new javax.swing.JLabel();
        txtSupplierID = new javax.swing.JTextField();
        txtSupplierName = new javax.swing.JTextField();
        txtContactNumber = new javax.swing.JTextField();
        btnAddSupplier = new javax.swing.JButton();
        btnUpdateSupplier = new javax.swing.JButton();
        btnDeleteSupplier = new javax.swing.JButton();
        btnClearFields = new javax.swing.JButton();
        btnSearchSupplier = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tableSuppliers = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(153, 153, 255));

        jPanel1.setBackground(new java.awt.Color(51, 51, 255));
        jPanel2.setBackground(new java.awt.Color(153, 153, 255));
        txtContactNumber.setBackground(new java.awt.Color(153, 153, 255));
        txtContactNumber.setBorder(null);
        jPanel4.setBackground(new java.awt.Color(153, 153, 255));
        jPanel4.setForeground(new java.awt.Color(255, 255, 255));

        // Add other buttons and action listeners for jPanel1

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(btnManageOrders, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnManageSuppliers, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnManageEmployees, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnManageProducts, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnManageMaterials, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnAllocateE2O, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnMonthlyIncomeExpenseReport)
                                        .addComponent(btnLogout))
                                .addGap(0, 21, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(49, 49, 49)
                                .addComponent(btnManageOrders)
                                .addGap(18, 18, 18)
                                .addComponent(btnManageSuppliers)
                                .addGap(18, 18, 18)
                                .addComponent(btnManageEmployees)
                                .addGap(18, 18, 18)
                                .addComponent(btnManageProducts)
                                .addGap(18, 18, 18)
                                .addComponent(btnManageMaterials)
                                .addGap(18, 18, 18)
                                .addComponent(btnAllocateE2O)
                                .addGap(18, 18, 18)
                                .addComponent(btnMonthlyIncomeExpenseReport)
                                .addGap(29, 29, 29)
                                .addComponent(btnLogout)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.setBackground(new java.awt.Color(153, 153, 255));

        jPanel4.setBackground(new java.awt.Color(153, 153, 255));
        jPanel4.setForeground(new java.awt.Color(255, 255, 255));

        jLabelSupplierID.setBackground(new java.awt.Color(0, 0, 204));
        jLabelSupplierID.setForeground(new java.awt.Color(255, 255, 255));
        jLabelSupplierID.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelSupplierID.setText("Supplier ID");
        jLabelSupplierID.setToolTipText("");
        jLabelSupplierID.setAlignmentX(0.5F);
        jLabelSupplierID.setBorder(new javax.swing.border.MatteBorder(null));

        jLabelSupplierName.setBackground(new java.awt.Color(0, 0, 204));
        jLabelSupplierName.setForeground(new java.awt.Color(255, 255, 255));
        jLabelSupplierName.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelSupplierName.setText("Supplier Name");
        jLabelSupplierName.setToolTipText("");
        jLabelSupplierName.setAlignmentX(0.5F);
        jLabelSupplierName.setBorder(new javax.swing.border.MatteBorder(null));

        jLabelContactNumber.setBackground(new java.awt.Color(0, 0, 204));
        jLabelContactNumber.setForeground(new java.awt.Color(255, 255, 255));
        jLabelContactNumber.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelContactNumber.setText("");
        jLabelContactNumber.setToolTipText("");
        jLabelContactNumber.setAlignmentX(0.5F);
        jLabelContactNumber.setBorder(new javax.swing.border.MatteBorder(null));

        btnLogout.setText("Logout");
        btnLogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLogoutActionPerformed(evt);
            }
        });

        btnAddSupplier.setBackground(new java.awt.Color(0, 0, 153));
        btnAddSupplier.setForeground(new java.awt.Color(255, 255, 255));
        btnAddSupplier.setText("ADD");
        btnAddSupplier.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnAddSupplier.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddSupplierActionPerformed(evt);
            }
        });

        btnUpdateSupplier.setBackground(new java.awt.Color(0, 0, 153));
        btnUpdateSupplier.setForeground(new java.awt.Color(255, 255, 255));
        btnUpdateSupplier.setText("UPDATE");
        btnUpdateSupplier.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnUpdateSupplier.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateSupplierActionPerformed(evt);
            }
        });

        btnDeleteSupplier.setBackground(new java.awt.Color(0, 0, 153));
        btnDeleteSupplier.setForeground(new java.awt.Color(255, 255, 255));
        btnDeleteSupplier.setText("DELETE");
        btnDeleteSupplier.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnDeleteSupplier.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteSupplierActionPerformed(evt);
            }
        });

        btnClearFields.setBackground(new java.awt.Color(0, 0, 153));
        btnClearFields.setForeground(new java.awt.Color(255, 255, 255));
        btnClearFields.setText("CLEAR");
        btnClearFields.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnClearFields.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearFieldsActionPerformed(evt);
            }
        });

        btnSearchSupplier.setBackground(new java.awt.Color(0, 0, 153));
        btnSearchSupplier.setForeground(new java.awt.Color(255, 255, 255));
        btnSearchSupplier.setText("SEARCH");
        btnSearchSupplier.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnSearchSupplier.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchSupplierActionPerformed(evt);
            }
        });

        btnManageEmployees.setText("Manage Employees");
        btnManageEmployees.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                btnManageEmployeesActionPerformed(evt);
            }
        });
        btnManageOrders.setText("Manage Orders");
        btnManageOrders.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                btnManageOrderActionPerformed(evt);
            }
        });
        btnManageSuppliers.setText("Manage Suppliers");
        btnManageSuppliers.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                btnManageSupplierActionPerformed(evt);
            }
        });
        btnManageMaterials.setText("Manage Materials");
        btnManageMaterials.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                btnManageMaterialActionPerformed(evt);
            }
        });
        btnManageProducts.setText("Manage Products");
        btnManageProducts.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                btnManageProductsActionPerformed(evt);
            }
        });

        jScrollPane2.setViewportView(tableSuppliers);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
                jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 600, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
                jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 427, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
                jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGap(37, 37, 37)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addGroup(jPanel4Layout.createSequentialGroup()
                                                .addComponent(btnSearchSupplier, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addGap(18, 18, 18)
                                                .addComponent(btnClearFields, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(jPanel4Layout.createSequentialGroup()
                                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                        .addComponent(jLabelContactNumber, javax.swing.GroupLayout.DEFAULT_SIZE, 110, Short.MAX_VALUE)
                                                        .addComponent(jLabelSupplierName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                        .addComponent(jLabelSupplierID, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                                .addGap(18, 18, 18)
                                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addGroup(jPanel4Layout.createSequentialGroup()
                                                                .addComponent(txtSupplierID, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                .addGap(18, 18, 18)
                                                                .addComponent(btnAddSupplier, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                        .addGroup(jPanel4Layout.createSequentialGroup()
                                                                .addComponent(txtSupplierName, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                .addGap(18, 18, 18)
                                                                .addComponent(btnDeleteSupplier, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                        .addGroup(jPanel4Layout.createSequentialGroup()
                                                                .addComponent(txtContactNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                .addGap(18, 18, 18)
                                                                .addComponent(btnUpdateSupplier, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                                        .addContainerGap(66, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
                jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGap(24, 24, 24)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabelSupplierID, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(txtSupplierID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnAddSupplier))
                                .addGap(10, 10, 10)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabelSupplierName, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(txtSupplierName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnDeleteSupplier))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabelContactNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(txtContactNumber, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnUpdateSupplier))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(btnClearFields)
                                        .addComponent(btnSearchSupplier))
                                .addContainerGap(30, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
                jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
                jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addContainerGap())
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addContainerGap())
        );

        pack();
    }

    private void refreshSupplierTable() {
        // Clear existing data from the table
        tableModel.setRowCount(0);

        // Retrieve all suppliers from the database
        List<Supplier> suppliers = supplierController.getAllSupplierFromDB();

        // Populate the table with the retrieved suppliers
        for (Supplier supplier : suppliers) {
            Object[] rowData = {supplier.getSupplierId(), supplier.getSupplierName()};
            tableModel.addRow(rowData);
        }
    }

    private void showSuppliersInTable() {
        String[] columnNames = {"Supplier ID", "Supplier Name", "Contact Number"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);

        List<Supplier> suppliers = supplierController.getAllSupplierFromDB();
        for (Supplier supplier : suppliers) {
            Object[] rowData = {supplier.getSupplierId(), supplier.getSupplierName()};
            model.addRow(rowData);
        }

        tableSuppliers.setModel(model); // Set the model for tableSuppliers
        tableSuppliers.setPreferredScrollableViewportSize(new Dimension(250, 100));
    }

    private void btnAddSupplierActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            String supplierName = txtSupplierName.getText();
            String contactNumber = txtContactNumber.getText();

            if (!supplierName.isEmpty()) {
                Supplier supplier = new Supplier(supplierName);
                boolean result = supplierController.insertSupplierToDB(supplier);

                if (result) {
                    JOptionPane.showMessageDialog(rootPane, "Supplier added successfully", "Success", JOptionPane.INFORMATION_MESSAGE);
                    refreshSupplierTable();
                } else {
                    JOptionPane.showMessageDialog(rootPane, "Error adding supplier to the database", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(rootPane, "Please enter valid Supplier Name and Contact Number", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(rootPane, "Invalid input format for Contact Number", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void btnUpdateSupplierActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            int supplierId = Integer.parseInt(txtSupplierID.getText());
            String supplierName = txtSupplierName.getText();
            String contactNumber = txtContactNumber.getText();

            if (supplierId > 0 && !supplierName.isEmpty()) {
                Supplier supplier = new Supplier(supplierName);
                supplier.setSupplierId(supplierId);
                boolean result = supplierController.updateSupplierInDB(supplier);

                if (result) {
                    JOptionPane.showMessageDialog(rootPane, "Supplier updated successfully", "Success", JOptionPane.INFORMATION_MESSAGE);
                    refreshSupplierTable();
                } else {
                    JOptionPane.showMessageDialog(rootPane, "Error updating supplier in the database", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(rootPane, "Please enter valid Supplier ID, Supplier Name, and Contact Number", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(rootPane, "Invalid input format for Supplier ID", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void btnDeleteSupplierActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            int supplierId = Integer.parseInt(txtSupplierID.getText());

            if (supplierId > 0) {
                Supplier supplier = new Supplier("");
                supplier.setSupplierId(supplierId);
                boolean result = supplierController.deleteSupplierFromDB(supplier);

                if (result) {
                    JOptionPane.showMessageDialog(rootPane, "Supplier deleted successfully", "Success", JOptionPane.INFORMATION_MESSAGE);
                    refreshSupplierTable();
                } else {
                    JOptionPane.showMessageDialog(rootPane, "Error deleting supplier from the database", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(rootPane, "Please enter a valid Supplier ID", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(rootPane, "Invalid input format for Supplier ID", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void btnSearchSupplierActionPerformed(ActionEvent evt) {
        try {
            int supplierId = Integer.parseInt(txtSupplierID.getText());

            if (supplierId > 0) {
                Supplier supplier = supplierController.searchBySupplierId(supplierId);

                if (supplier != null) {
                    // Supplier found in the database, display its details in the text fields
                    txtSupplierName.setText(supplier.getSupplierName());
                    JOptionPane.showMessageDialog(rootPane, "Supplier found in the database", "Success", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    // Supplier not found in the database
                    JOptionPane.showMessageDialog(rootPane, "Supplier not found in the database", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(rootPane, "Please enter a valid Supplier ID", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(rootPane, "Invalid input format for Supplier ID", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void btnClearFieldsActionPerformed(java.awt.event.ActionEvent evt) {
        clearFields();
    }

    private void clearFields() {
        // Clear the text fields
        txtSupplierID.setText("");
        txtSupplierName.setText("");
        txtContactNumber.setText("");
    }
    private void btnLogoutActionPerformed(java.awt.event.ActionEvent evt) {
        LoginView loginView = new LoginView();
        loginView.setVisible(true);
        this.setVisible(false);
    }
    private void btnManageProductsActionPerformed(java.awt.event.ActionEvent evt) {
        // Create a new instance of EmployeeView
        ProductView productView = new ProductView();

        // Close the current EmployeeView
        this.dispose();

        // Display the new EmployeeView
        productView .setVisible(true);
    }
    private void btnManageEmployeesActionPerformed(java.awt.event.ActionEvent evt) {
        // Create a new instance of EmployeeView
        EmployeeView employeeView = new EmployeeView();

        // Close the current EmployeeView
        this.dispose();

        // Display the new EmployeeView
        employeeView.setVisible(true);
    }
    private void btnManageSupplierActionPerformed(java.awt.event.ActionEvent evt) {
        // Create a new instance of SupplierView
        SupplierView supplierView = new SupplierView();

        // Close the current SupplierView
        this.dispose();

        // Display the new SupplierView
        supplierView.setVisible(true);
    }

    private void btnManageMaterialActionPerformed(java.awt.event.ActionEvent evt) {
        // Create a new instance of MaterialView
        MaterialView materialView = new MaterialView();

        // Close the current SupplierView
        this.dispose();

        // Display the new MaterialView
        materialView.setVisible(true);
    }

    private void btnManageOrderActionPerformed(java.awt.event.ActionEvent evt) {
        // Create a new instance of OrderView
        OrderView orderView = new OrderView();

        // Close the current SupplierView
        this.dispose();

        // Display the new OrderView
        orderView.setVisible(true);
    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SupplierView().setVisible(true);
            }
        });
    }

    // Variables declaration
    private javax.swing.JButton btnAddSupplier;
    private javax.swing.JButton btnClearFields;
    private javax.swing.JButton btnDeleteSupplier;
    private javax.swing.JButton btnManageEmployees;
    private javax.swing.JButton btnManageMaterials;
    private javax.swing.JButton btnManageOrders;
    private javax.swing.JButton btnManageProducts;
    private javax.swing.JButton btnManageSuppliers;
    private javax.swing.JButton btnMonthlyIncomeExpenseReport;
    private javax.swing.JButton btnSearchSupplier;
    private javax.swing.JButton btnUpdateSupplier;
    private javax.swing.JButton btnAllocateE2O;
    private javax.swing.JButton btnLogout;
    private javax.swing.JLabel jLabelContactNumber;
    private javax.swing.JLabel jLabelSupplierName;
    private javax.swing.JLabel jLabelSupplierID;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField txtSupplierID;
    private javax.swing.JTextField txtSupplierName;
    private javax.swing.JTextField txtContactNumber;
}
