package Views;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import Controllers.OrderController;
import Models.Order;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.List;

public class OrderView extends javax.swing.JFrame {

    Order objOrder;
    OrderController orderController;
    DefaultTableModel tableModel;
    JTable tableOrders;

    public OrderView() {
        initComponents();
        orderController = new OrderController();
        tableModel = new DefaultTableModel();
        tableModel.addColumn("Order ID");
        tableModel.addColumn("Product ID");
        tableModel.addColumn("Customer ID");
        tableOrders = new JTable(tableModel); // Using the existing tableOrders variable
        jScrollPane2.setViewportView(tableOrders);
        refreshOrderTable();
    }

    private void initComponents() {
        jPanel1 = new javax.swing.JPanel();
        btnManageOrders = new javax.swing.JButton();
        btnManageSuppliers = new javax.swing.JButton();
        btnManageEmployees = new javax.swing.JButton();
        btnManageProducts = new javax.swing.JButton();
        btnManageMaterials = new javax.swing.JButton();
        btnAllocateE2O = new javax.swing.JButton();
        btnMonthlyIncomeExpenseReport = new javax.swing.JButton();
        btnLogout = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jLabelOrderID = new javax.swing.JLabel();
        jLabelProductID = new javax.swing.JLabel();
        jLabelCustomerID = new javax.swing.JLabel();
        txtOrderID = new javax.swing.JTextField();
        txtProductID = new javax.swing.JTextField();
        txtCustomerID = new javax.swing.JTextField();
        btnAddOrder = new javax.swing.JButton();
        btnUpdateOrder = new javax.swing.JButton();
        btnDeleteOrder = new javax.swing.JButton();
        btnClearFields = new javax.swing.JButton();
        btnSearchOrder = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tableOrders = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(153, 153, 255));

        jPanel1.setBackground(new java.awt.Color(51, 51, 255));
        jPanel2.setBackground(new java.awt.Color(153, 153, 255));

        jPanel4.setBackground(new java.awt.Color(153, 153, 255));
        jPanel4.setForeground(new java.awt.Color(255, 255, 255));



        // Add other buttons and action listeners for jPanel1

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(btnManageOrders, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnManageSuppliers, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnManageEmployees, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnManageProducts, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnManageMaterials, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnAllocateE2O, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnMonthlyIncomeExpenseReport)
                                        .addComponent(btnLogout))
                                .addGap(0, 21, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(49, 49, 49)
                                .addComponent(btnManageOrders)
                                .addGap(18, 18, 18)
                                .addComponent(btnManageSuppliers)
                                .addGap(18, 18, 18)
                                .addComponent(btnManageEmployees)
                                .addGap(18, 18, 18)
                                .addComponent(btnManageProducts)
                                .addGap(18, 18, 18)
                                .addComponent(btnManageMaterials)
                                .addGap(18, 18, 18)
                                .addComponent(btnAllocateE2O)
                                .addGap(18, 18, 18)
                                .addComponent(btnMonthlyIncomeExpenseReport)
                                .addGap(29, 29, 29)
                                .addComponent(btnLogout)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.setBackground(new java.awt.Color(153, 153, 255));

        jPanel4.setBackground(new java.awt.Color(153, 153, 255));
        jPanel4.setForeground(new java.awt.Color(255, 255, 255));

        jLabelOrderID.setBackground(new java.awt.Color(0, 0, 204));
        jLabelOrderID.setForeground(new java.awt.Color(255, 255, 255));
        jLabelOrderID.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelOrderID.setText("Order ID");
        jLabelOrderID.setToolTipText("");
        jLabelOrderID.setAlignmentX(0.5F);
        jLabelOrderID.setBorder(new javax.swing.border.MatteBorder(null));

        jLabelProductID.setBackground(new java.awt.Color(0, 0, 204));
        jLabelProductID.setForeground(new java.awt.Color(255, 255, 255));
        jLabelProductID.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelProductID.setText("Product ID");
        jLabelProductID.setToolTipText("");
        jLabelProductID.setAlignmentX(0.5F);
        jLabelProductID.setBorder(new javax.swing.border.MatteBorder(null));

        jLabelCustomerID.setBackground(new java.awt.Color(0, 0, 204));
        jLabelCustomerID.setForeground(new java.awt.Color(255, 255, 255));
        jLabelCustomerID.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelCustomerID.setText("Customer ID");
        jLabelCustomerID.setToolTipText("");
        jLabelCustomerID.setAlignmentX(0.5F);
        jLabelCustomerID.setBorder(new javax.swing.border.MatteBorder(null));

        btnLogout.setText("Logout");
        btnLogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLogoutActionPerformed(evt);
            }
        });

        btnAddOrder.setBackground(new java.awt.Color(0, 0, 153));
        btnAddOrder.setForeground(new java.awt.Color(255, 255, 255));
        btnAddOrder.setText("ADD");
        btnAddOrder.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnAddOrder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddOrderActionPerformed(evt);
            }
        });

        btnUpdateOrder.setBackground(new java.awt.Color(0, 0, 153));
        btnUpdateOrder.setForeground(new java.awt.Color(255, 255, 255));
        btnUpdateOrder.setText("UPDATE");
        btnUpdateOrder.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnUpdateOrder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateOrderActionPerformed(evt);
            }
        });

        btnDeleteOrder.setBackground(new java.awt.Color(0, 0, 153));
        btnDeleteOrder.setForeground(new java.awt.Color(255, 255, 255));
        btnDeleteOrder.setText("DELETE");
        btnDeleteOrder.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnDeleteOrder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteOrderActionPerformed(evt);
            }
        });

        btnClearFields.setBackground(new java.awt.Color(0, 0, 153));
        btnClearFields.setForeground(new java.awt.Color(255, 255, 255));
        btnClearFields.setText("CLEAR");
        btnClearFields.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnClearFields.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearFieldsActionPerformed(evt);
            }
        });

        btnSearchOrder.setBackground(new java.awt.Color(0, 0, 153));
        btnSearchOrder.setForeground(new java.awt.Color(255, 255, 255));
        btnSearchOrder.setText("SEARCH");
        btnSearchOrder.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnSearchOrder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchOrderActionPerformed(evt);
            }
        });

        btnManageEmployees.setText("Manage Employees");
        btnManageEmployees.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                btnManageEmployeesActionPerformed(evt);
            }
        });
        btnManageOrders.setText("Manage Orders");
        btnManageOrders.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                btnManageOrderActionPerformed(evt);
            }
        });
        btnManageSuppliers.setText("Manage Suppliers");
        btnManageSuppliers.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                btnManageSupplierActionPerformed(evt);
            }
        });
        btnManageMaterials.setText("Manage Materials");
        btnManageMaterials.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                btnManageMaterialActionPerformed(evt);
            }
        });
        btnManageProducts.setText("Manage Products");
        btnManageProducts.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                btnManageProductsActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
                jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGap(37, 37, 37)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addGroup(jPanel4Layout.createSequentialGroup()
                                                .addComponent(btnSearchOrder, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addGap(18, 18, 18)
                                                .addComponent(btnClearFields, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(jPanel4Layout.createSequentialGroup()
                                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                        .addComponent(jLabelCustomerID, javax.swing.GroupLayout.DEFAULT_SIZE, 78, Short.MAX_VALUE)
                                                        .addComponent(jLabelProductID, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                        .addComponent(jLabelOrderID, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                                .addGap(18, 18, 18)
                                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addGroup(jPanel4Layout.createSequentialGroup()
                                                                .addComponent(txtOrderID, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                .addGap(18, 18, 18)
                                                                .addComponent(btnAddOrder, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                        .addGroup(jPanel4Layout.createSequentialGroup()
                                                                .addComponent(txtProductID, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                .addGap(18, 18, 18)
                                                                .addComponent(btnDeleteOrder, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                        .addGroup(jPanel4Layout.createSequentialGroup()
                                                                .addComponent(txtCustomerID, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                .addGap(18, 18, 18)
                                                                .addComponent(btnUpdateOrder, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                .addContainerGap(66, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
                jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGap(24, 24, 24)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabelOrderID, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(txtOrderID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnAddOrder))
                                .addGap(10, 10, 10)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabelProductID, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(txtProductID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnDeleteOrder))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabelCustomerID, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(txtCustomerID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnUpdateOrder))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(btnClearFields)
                                        .addComponent(btnSearchOrder))
                                .addContainerGap(30, Short.MAX_VALUE))
        );

        jPanel5.setLayout(new BorderLayout());
        jScrollPane2.setViewportView(tableOrders);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
                jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 600, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
                jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 427, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
                jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
                jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addContainerGap())
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addContainerGap())
        );

        pack();
    }

    private void refreshOrderTable() {
        // Clear existing data from the table
        tableModel.setRowCount(0);

        // Retrieve all orders from the database
        List<Order> orders = orderController.getAllOrdersFromDB();

        // Populate the table with the retrieved orders
        for (Order order : orders) {
            Object[] rowData = {order.getOrderId(), order.getProductId(), order.getCustomerId()};
            tableModel.addRow(rowData);
        }
    }

    private void showOrdersInTable() {
        String[] columnNames = {"Order ID", "Product ID", "Customer ID"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);

        List<Order> orders = orderController.getAllOrdersFromDB();
        for (Order order : orders) {
            Object[] rowData = {order.getOrderId(), order.getProductId(), order.getCustomerId()};
            model.addRow(rowData);
        }

        tableOrders.setModel(model); // Set the model for jTable1
        tableOrders.setPreferredScrollableViewportSize(new Dimension(250, 100));
    }
    private void btnManageProductsActionPerformed(java.awt.event.ActionEvent evt) {
        // Create a new instance of EmployeeView
        ProductView productView = new ProductView();

        // Close the current EmployeeView
        this.dispose();

        // Display the new EmployeeView
        productView .setVisible(true);
    }
    private void btnAddOrderActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            int customerId = Integer.parseInt(txtCustomerID.getText());
            int productId = Integer.parseInt(txtProductID.getText());

            if (customerId > 0 && productId > 0) {
                objOrder = new Order(customerId, productId);
                boolean result = orderController.insertOrderToDB(objOrder);

                if (result) {
                    JOptionPane.showMessageDialog(rootPane, "Order added successfully", "Success", JOptionPane.INFORMATION_MESSAGE);
                    refreshOrderTable();
                } else {
                    JOptionPane.showMessageDialog(rootPane, "Error adding order to the database", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(rootPane, "Please enter valid Customer ID and Product ID", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(rootPane, "Invalid input format for Customer ID or Product ID", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void btnUpdateOrderActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            int orderId = Integer.parseInt(txtOrderID.getText());
            int customerId = Integer.parseInt(txtCustomerID.getText());
            int productId = Integer.parseInt(txtProductID.getText());

            if (orderId > 0 && customerId > 0 && productId > 0) {
                objOrder = new Order(customerId, productId);
                objOrder.setOrderId(orderId);
                boolean result = orderController.updateOrderInDB(objOrder);

                if (result) {
                    JOptionPane.showMessageDialog(rootPane, "Order updated successfully", "Success", JOptionPane.INFORMATION_MESSAGE);
                    refreshOrderTable();
                } else {
                    JOptionPane.showMessageDialog(rootPane, "Error updating order in the database", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(rootPane, "Please enter valid Order ID, Customer ID, and Product ID", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(rootPane, "Invalid input format for Order ID, Customer ID, or Product ID", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void btnDeleteOrderActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            int orderId = Integer.parseInt(txtOrderID.getText());

            if (orderId > 0) {
                objOrder = new Order(0, 0);
                objOrder.setOrderId(orderId);
                boolean result = orderController.deleteOrderFromDB(objOrder);

                if (result) {
                    JOptionPane.showMessageDialog(rootPane, "Order deleted successfully", "Success", JOptionPane.INFORMATION_MESSAGE);
                    refreshOrderTable();
                } else {
                    JOptionPane.showMessageDialog(rootPane, "Error deleting order from the database", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(rootPane, "Please enter a valid Order ID", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(rootPane, "Invalid input format for Order ID", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void btnSearchOrderActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            int orderId = Integer.parseInt(txtOrderID.getText());

            if (orderId > 0) {
                objOrder = orderController.searchById(orderId);

                if (objOrder != null) {
                    // Order found in the database, display its details in the text fields
                    txtCustomerID.setText(String.valueOf(objOrder.getCustomerId()));
                    txtProductID.setText(String.valueOf(objOrder.getProductId()));
                    JOptionPane.showMessageDialog(rootPane, "Order found in the database", "Success", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    // Order not found in the database
                    JOptionPane.showMessageDialog(rootPane, "Order not found in the database", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(rootPane, "Please enter a valid Order ID", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(rootPane, "Invalid input format for Order ID", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void btnClearFieldsActionPerformed(java.awt.event.ActionEvent evt) {
        clearFields();
    }

    private void clearFields() {
        // Clear the text fields
        txtOrderID.setText("");
        txtProductID.setText("");
        txtCustomerID.setText("");
    }
    private void btnManageEmployeesActionPerformed(java.awt.event.ActionEvent evt) {
        // Create a new instance of EmployeeView
        EmployeeView employeeView = new EmployeeView();

        // Close the current EmployeeView
        this.dispose();

        // Display the new EmployeeView
        employeeView.setVisible(true);
    }
    private void btnManageOrderActionPerformed(java.awt.event.ActionEvent evt) {
        // Create a new instance of OrderView
        OrderView orderView = new OrderView();

        // Close the current OrderView
        this.dispose();

        // Display the new OrderView
        orderView.setVisible(true);
    }
    private void btnManageSupplierActionPerformed(java.awt.event.ActionEvent evt) {
        // Create a new instance of OrderView
        SupplierView supplierView = new SupplierView();

        // Close the current OrderView
        this.dispose();

        // Display the new OrderView
        supplierView.setVisible(true);
    }
    private void btnManageMaterialActionPerformed(java.awt.event.ActionEvent evt) {
        // Create a new instance of OrderView
        MaterialView materialView = new MaterialView();

        // Close the current OrderView
        this.dispose();

        // Display the new OrderView
        materialView.setVisible(true);
    }
    private void btnLogoutActionPerformed(java.awt.event.ActionEvent evt) {
        LoginView loginView = new LoginView();
        loginView.setVisible(true);
        this.setVisible(false);
    }

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(OrderView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new OrderView().setVisible(true);
        });
    }

    // Variables declaration - do not modify
    private javax.swing.JButton btnAddOrder;
    private javax.swing.JButton btnDeleteOrder;
    private javax.swing.JButton btnUpdateOrder;
    private javax.swing.JButton btnClearFields;
    private javax.swing.JButton btnSearchOrder;
    private javax.swing.JButton btnLogout;
    private javax.swing.JButton btnMonthlyIncomeExpenseReport;
    private javax.swing.JButton btnAllocateE2O;
    private javax.swing.JButton btnManageMaterials;
    private javax.swing.JButton btnManageProducts;
    private javax.swing.JButton btnManageEmployees;
    private javax.swing.JButton btnManageSuppliers;
    private javax.swing.JButton btnManageOrders;
    private javax.swing.JLabel jLabelCustomerID;
    private javax.swing.JLabel jLabelOrderID;
    private javax.swing.JLabel jLabelProductID;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField txtCustomerID;
    private javax.swing.JTextField txtOrderID;
    private javax.swing.JTextField txtProductID;

    // End of variables declaration
}
