package Views;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import Controllers.EmployeeController;
import Models.Employee;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.List;

public class EmployeeView extends javax.swing.JFrame {

    Employee objEmployee;
    EmployeeController employeeController;
    DefaultTableModel tableModel;
    JTable tableEmployees;

    public EmployeeView() {
        initComponents();
        employeeController = new EmployeeController();
        tableModel = new DefaultTableModel();
        tableModel.addColumn("Employee ID");
        tableModel.addColumn("Employee Name");
        tableEmployees = new JTable(tableModel); // Using the existing tableEmployees variable
        jScrollPane2.setViewportView(tableEmployees);
        refreshEmployeeTable();
    }

    private void initComponents() {
        jPanel1 = new javax.swing.JPanel();
        btnManageOrders = new javax.swing.JButton();
        btnManageEmployees = new javax.swing.JButton();
        btnManageSuppliers = new javax.swing.JButton();
        btnManageProducts = new javax.swing.JButton();
        btnManageMaterials = new javax.swing.JButton();
        btnAllocateE2O = new javax.swing.JButton();
        btnMonthlyIncomeExpenseReport = new javax.swing.JButton();
        btnLogout = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jLabelEmployeeID = new javax.swing.JLabel();
        jLabelEmployeeName = new javax.swing.JLabel();
        txtEmployeeID = new javax.swing.JTextField();
        txtEmployeeName = new javax.swing.JTextField();
        btnAddEmployee = new javax.swing.JButton();
        btnUpdateEmployee = new javax.swing.JButton();
        btnDeleteEmployee = new javax.swing.JButton();
        btnClearFields = new javax.swing.JButton();
        btnSearchEmployee = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tableEmployees = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(153, 153, 255));

        jPanel1.setBackground(new java.awt.Color(51, 51, 255));
        jPanel2.setBackground(new java.awt.Color(153, 153, 255));
        jPanel4.setBackground(new java.awt.Color(153, 153, 255));
        jPanel4.setForeground(new java.awt.Color(255, 255, 255));




        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(btnManageOrders, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnManageSuppliers, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnManageEmployees, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnManageProducts, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnManageMaterials, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnAllocateE2O, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnMonthlyIncomeExpenseReport)
                                        .addComponent(btnLogout))
                                .addGap(0, 21, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(49, 49, 49)
                                .addComponent(btnManageOrders)
                                .addGap(18, 18, 18)
                                .addComponent(btnManageSuppliers)
                                .addGap(18, 18, 18)
                                .addComponent(btnManageEmployees)
                                .addGap(18, 18, 18)
                                .addComponent(btnManageProducts)
                                .addGap(18, 18, 18)
                                .addComponent(btnManageMaterials)
                                .addGap(18, 18, 18)
                                .addComponent(btnAllocateE2O)
                                .addGap(18, 18, 18)
                                .addComponent(btnMonthlyIncomeExpenseReport)
                                .addGap(29, 29, 29)
                                .addComponent(btnLogout)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.setBackground(new java.awt.Color(153, 153, 255));

        jPanel4.setBackground(new java.awt.Color(153, 153, 255));
        jPanel4.setForeground(new java.awt.Color(255, 255, 255));

        jLabelEmployeeID.setBackground(new java.awt.Color(0, 0, 204));
        jLabelEmployeeID.setForeground(new java.awt.Color(255, 255, 255));
        jLabelEmployeeID.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelEmployeeID.setText("Employee ID");
        jLabelEmployeeID.setToolTipText("");
        jLabelEmployeeID.setAlignmentX(0.5F);
        jLabelEmployeeID.setBorder(new javax.swing.border.MatteBorder(null));

        jLabelEmployeeName.setBackground(new java.awt.Color(0, 0, 204));
        jLabelEmployeeName.setForeground(new java.awt.Color(255, 255, 255));
        jLabelEmployeeName.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelEmployeeName.setText("Employee Name");
        jLabelEmployeeName.setToolTipText("");
        jLabelEmployeeName.setAlignmentX(0.5F);
        jLabelEmployeeName.setBorder(new javax.swing.border.MatteBorder(null));

        btnLogout.setText("Logout");
        btnLogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLogoutActionPerformed(evt);
            }
        });

        btnAddEmployee.setBackground(new java.awt.Color(0, 0, 153));
        btnAddEmployee.setForeground(new java.awt.Color(255, 255, 255));
        btnAddEmployee.setText("ADD");
        btnAddEmployee.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnAddEmployee.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddEmployeeActionPerformed(evt);
            }
        });

        btnUpdateEmployee.setBackground(new java.awt.Color(0, 0, 153));
        btnUpdateEmployee.setForeground(new java.awt.Color(255, 255, 255));
        btnUpdateEmployee.setText("UPDATE");
        btnUpdateEmployee.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnUpdateEmployee.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateEmployeeActionPerformed(evt);
            }
        });

        btnDeleteEmployee.setBackground(new java.awt.Color(0, 0, 153));
        btnDeleteEmployee.setForeground(new java.awt.Color(255, 255, 255));
        btnDeleteEmployee.setText("DELETE");
        btnDeleteEmployee.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnDeleteEmployee.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteEmployeeActionPerformed(evt);
            }
        });

        btnClearFields.setBackground(new java.awt.Color(0, 0, 153));
        btnClearFields.setForeground(new java.awt.Color(255, 255, 255));
        btnClearFields.setText("CLEAR");
        btnClearFields.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnClearFields.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearFieldsActionPerformed(evt);
            }
        });

        btnSearchEmployee.setBackground(new java.awt.Color(0, 0, 153));
        btnSearchEmployee.setForeground(new java.awt.Color(255, 255, 255));
        btnSearchEmployee.setText("SEARCH");
        btnSearchEmployee.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnSearchEmployee.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchEmployeeActionPerformed(evt);
            }
        });

        btnManageEmployees.setText("Manage Employees");
        btnManageEmployees.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                btnManageEmployeesActionPerformed(evt);
            }
        });
        btnManageOrders.setText("Manage Orders");
        btnManageOrders.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                btnManageOrderActionPerformed(evt);
            }
        });
        btnManageSuppliers.setText("Manage Suppliers");
        btnManageSuppliers.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                btnManageSupplierActionPerformed(evt);
            }
        });
        btnManageMaterials.setText("Manage Materials");
        btnManageMaterials.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                btnManageMaterialActionPerformed(evt);
            }
        });
        btnManageProducts.setText("Manage Products");
        btnManageProducts.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                btnManageProductsActionPerformed(evt);
            }
        });


        jScrollPane2.setViewportView(tableEmployees);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
                jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 600, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
                jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 427, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
                jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGap(37, 37, 37)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addGroup(jPanel4Layout.createSequentialGroup()
                                                .addComponent(btnSearchEmployee, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addGap(18, 18, 18)
                                                .addComponent(btnClearFields, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(jPanel4Layout.createSequentialGroup()
                                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                        .addComponent(jLabelEmployeeName, javax.swing.GroupLayout.DEFAULT_SIZE, 110, Short.MAX_VALUE)
                                                        .addComponent(jLabelEmployeeID, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                                .addGap(18, 18, 18)
                                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addGroup(jPanel4Layout.createSequentialGroup()
                                                                .addComponent(txtEmployeeID, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                .addGap(18, 18, 18)
                                                                .addComponent(btnAddEmployee, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                        .addGroup(jPanel4Layout.createSequentialGroup()
                                                                .addComponent(txtEmployeeName, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                .addGap(18, 18, 18)
                                                                .addComponent(btnUpdateEmployee, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE) // Corrected placement
                                                                .addGap(18, 18, 18)
                                                                .addComponent(btnDeleteEmployee, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                .addContainerGap(66, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
                jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGap(24, 24, 24)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabelEmployeeID, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(txtEmployeeID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnAddEmployee))
                                .addGap(10, 10, 10)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabelEmployeeName, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(txtEmployeeName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnUpdateEmployee) // Corrected placement
                                        .addComponent(btnDeleteEmployee))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(btnSearchEmployee)
                                        .addComponent(btnClearFields))
                                .addContainerGap(30, Short.MAX_VALUE))
        );


        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
                jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
                jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addContainerGap())
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addContainerGap())
        );

        pack();
    }

    private void refreshEmployeeTable() {
        // Clear existing data from the table
        tableModel.setRowCount(0);

        // Retrieve all employees from the database
        List<Employee> employees = employeeController.getAllEmployeesFromDB();

        // Populate the table with the retrieved employees
        for (Employee employee : employees) {
            Object[] rowData = {employee.getEmployeeId(), employee.getEmployeeName()};
            tableModel.addRow(rowData);
        }
    }

    private void showEmployeesInTable() {
        String[] columnNames = {"Employee ID", "Employee Name"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);

        List<Employee> employees = employeeController.getAllEmployeesFromDB();
        for (Employee employee : employees) {
            Object[] rowData = {employee.getEmployeeId(), employee.getEmployeeName()};
            model.addRow(rowData);
        }

        tableEmployees.setModel(model); // Set the model for tableEmployees
        tableEmployees.setPreferredScrollableViewportSize(new Dimension(250, 100));
    }

    private void btnAddEmployeeActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            String employeeName = txtEmployeeName.getText();

            if (!employeeName.isEmpty()) {
                Employee employee = new Employee(employeeName);
                boolean result = employeeController.insertEmployeeToDB(employee);

                if (result) {
                    JOptionPane.showMessageDialog(rootPane, "Employee added successfully", "Success", JOptionPane.INFORMATION_MESSAGE);
                    refreshEmployeeTable();
                } else {
                    JOptionPane.showMessageDialog(rootPane, "Error adding employee to the database", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(rootPane, "Please enter valid Employee Name", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(rootPane, "Invalid input format for Employee ID", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void btnUpdateEmployeeActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            int employeeId = Integer.parseInt(txtEmployeeID.getText());
            String employeeName = txtEmployeeName.getText();

            if (employeeId > 0 && !employeeName.isEmpty()) {
                Employee employee = new Employee(employeeName);
                employee.setEmployeeId(employeeId);
                boolean result = employeeController.updateEmployeeInDB(employee);

                if (result) {
                    JOptionPane.showMessageDialog(rootPane, "Employee updated successfully", "Success", JOptionPane.INFORMATION_MESSAGE);
                    refreshEmployeeTable();
                } else {
                    JOptionPane.showMessageDialog(rootPane, "Error updating employee in the database", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(rootPane, "Please enter valid Employee ID and Employee Name", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(rootPane, "Invalid input format for Employee ID", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void btnDeleteEmployeeActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            int employeeId = Integer.parseInt(txtEmployeeID.getText());

            if (employeeId > 0) {
                Employee employee = new Employee("");
                employee.setEmployeeId(employeeId);
                boolean result = employeeController.deleteEmployeeFromDB(employee);

                if (result) {
                    JOptionPane.showMessageDialog(rootPane, "Employee deleted successfully", "Success", JOptionPane.INFORMATION_MESSAGE);
                    refreshEmployeeTable();
                } else {
                    JOptionPane.showMessageDialog(rootPane, "Error deleting employee from the database", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(rootPane, "Please enter a valid Employee ID", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(rootPane, "Invalid input format for Employee ID", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void btnSearchEmployeeActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            int employeeId = Integer.parseInt(txtEmployeeID.getText());

            if (employeeId > 0) {
                Employee employee = employeeController.searchByEmployeeId(employeeId);

                if (employee != null) {
                    // Employee found in the database, display its details in the text fields
                    txtEmployeeName.setText(employee.getEmployeeName());
                    JOptionPane.showMessageDialog(rootPane, "Employee found in the database", "Success", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    // Employee not found in the database
                    JOptionPane.showMessageDialog(rootPane, "Employee not found in the database", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(rootPane, "Please enter a valid Employee ID", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(rootPane, "Invalid input format for Employee ID", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void btnClearFieldsActionPerformed(java.awt.event.ActionEvent evt) {
        clearFields();
    }

    private void clearFields() {
        // Clear the text fields
        txtEmployeeID.setText("");
        txtEmployeeName.setText("");
    }

    private void btnManageEmployeesActionPerformed(java.awt.event.ActionEvent evt) {
        // Create a new instance of EmployeeView
        EmployeeView employeeView = new EmployeeView();

        // Close the current EmployeeView
        this.dispose();

        // Display the new EmployeeView
        employeeView.setVisible(true);
    }

    private void btnManageSupplierActionPerformed(java.awt.event.ActionEvent evt) {
        // Create a new instance of SupplierView
        SupplierView supplierView = new SupplierView();

        // Close the current SupplierView
        this.dispose();

        // Display the new SupplierView
        supplierView.setVisible(true);
    }

    private void btnManageMaterialActionPerformed(java.awt.event.ActionEvent evt) {
        // Create a new instance of MaterialView
        MaterialView materialView = new MaterialView();

        // Close the current SupplierView
        this.dispose();

        // Display the new MaterialView
        materialView.setVisible(true);
    }

    private void btnManageOrderActionPerformed(java.awt.event.ActionEvent evt) {
        // Create a new instance of OrderView
        OrderView orderView = new OrderView();

        // Close the current SupplierView
        this.dispose();

        // Display the new OrderView
        orderView.setVisible(true);
    }
    private void btnManageProductsActionPerformed(java.awt.event.ActionEvent evt) {
        // Create a new instance of EmployeeView
        ProductView productView = new ProductView();

        // Close the current EmployeeView
        this.dispose();

        // Display the new EmployeeView
        productView .setVisible(true);
    }
    private void btnLogoutActionPerformed(java.awt.event.ActionEvent evt) {
        LoginView loginView = new LoginView();
        loginView.setVisible(true);
        this.setVisible(false);
    }


    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EmployeeView().setVisible(true);
            }
        });
    }

    // Variables declaration
    private javax.swing.JButton btnAddEmployee;
    private javax.swing.JButton btnClearFields;
    private javax.swing.JButton btnDeleteEmployee;
    private javax.swing.JButton btnManageEmployees;
    private javax.swing.JButton btnManageSuppliers;
    private javax.swing.JButton btnManageProducts;
    private javax.swing.JButton btnManageOrders;
    private javax.swing.JButton btnManageMaterials;
    private javax.swing.JButton btnSearchEmployee;
    private javax.swing.JButton btnUpdateEmployee;
    private javax.swing.JButton btnAllocateE2O;
    private javax.swing.JButton btnMonthlyIncomeExpenseReport;
    private javax.swing.JButton btnLogout;
    private javax.swing.JLabel jLabelEmployeeName;
    private javax.swing.JLabel jLabelEmployeeID;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField txtEmployeeID;
    private javax.swing.JTextField txtEmployeeName;
    // End of variables declaration
}
