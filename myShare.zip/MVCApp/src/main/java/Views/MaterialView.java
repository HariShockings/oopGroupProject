package Views;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import Controllers.MaterialController;
import Models.Material;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.List;

public class MaterialView extends javax.swing.JFrame {

    Material objMaterial;
    MaterialController materialController;
    DefaultTableModel tableModel;
    JTable tableMaterials;

    public MaterialView() {
        initComponents();
        materialController = new MaterialController();
        tableModel = new DefaultTableModel();
        tableModel.addColumn("Material ID");
        tableModel.addColumn("Material Name");
        tableModel.addColumn("Quantity");
        tableMaterials = new JTable(tableModel); // Using the existing tableMaterials variable
        jScrollPane2.setViewportView(tableMaterials);
        refreshMaterialTable();
    }

    private void initComponents() {
        jPanel1 = new javax.swing.JPanel();
        btnManageOrders = new javax.swing.JButton();
        btnManageSuppliers = new javax.swing.JButton();
        btnManageEmployees = new javax.swing.JButton();
        btnManageProducts = new javax.swing.JButton();
        btnManageMaterials = new javax.swing.JButton();
        btnAllocateE2O = new javax.swing.JButton();
        btnMonthlyIncomeExpenseReport = new javax.swing.JButton();
        btnLogout = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jLabelMaterialID = new javax.swing.JLabel();
        jLabelMaterialName = new javax.swing.JLabel();
        jLabelQuantity = new javax.swing.JLabel();
        txtMaterialID = new javax.swing.JTextField();
        txtMaterialName = new javax.swing.JTextField();
        txtQuantity = new javax.swing.JTextField();
        btnAddMaterial = new javax.swing.JButton();
        btnUpdateMaterial = new javax.swing.JButton();
        btnDeleteMaterial = new javax.swing.JButton();
        btnClearFields = new javax.swing.JButton();
        btnSearchMaterial = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tableMaterials = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(153, 153, 255));

        jPanel1.setBackground(new java.awt.Color(51, 51, 255));
        jPanel2.setBackground(new java.awt.Color(153, 153, 255));

        jPanel4.setBackground(new java.awt.Color(153, 153, 255));
        jPanel4.setForeground(new java.awt.Color(255, 255, 255));


        // Add other buttons and action listeners for jPanel1

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(btnManageOrders, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnManageSuppliers, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnManageEmployees, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnManageProducts, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnManageMaterials, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnAllocateE2O, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnMonthlyIncomeExpenseReport)
                                        .addComponent(btnLogout))
                                .addGap(0, 21, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(49, 49, 49)
                                .addComponent(btnManageOrders)
                                .addGap(18, 18, 18)
                                .addComponent(btnManageSuppliers)
                                .addGap(18, 18, 18)
                                .addComponent(btnManageEmployees)
                                .addGap(18, 18, 18)
                                .addComponent(btnManageProducts)
                                .addGap(18, 18, 18)
                                .addComponent(btnManageMaterials)
                                .addGap(18, 18, 18)
                                .addComponent(btnAllocateE2O)
                                .addGap(18, 18, 18)
                                .addComponent(btnMonthlyIncomeExpenseReport)
                                .addGap(29, 29, 29)
                                .addComponent(btnLogout)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.setBackground(new java.awt.Color(153, 153, 255));

        jPanel4.setBackground(new java.awt.Color(153, 153, 255));
        jPanel4.setForeground(new java.awt.Color(255, 255, 255));

        jLabelMaterialID.setBackground(new java.awt.Color(0, 0, 204));
        jLabelMaterialID.setForeground(new java.awt.Color(255, 255, 255));
        jLabelMaterialID.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelMaterialID.setText("Material ID");
        jLabelMaterialID.setToolTipText("");
        jLabelMaterialID.setAlignmentX(0.5F);
        jLabelMaterialID.setBorder(new javax.swing.border.MatteBorder(null));

        jLabelMaterialName.setBackground(new java.awt.Color(0, 0, 204));
        jLabelMaterialName.setForeground(new java.awt.Color(255, 255, 255));
        jLabelMaterialName.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelMaterialName.setText("Material Name");
        jLabelMaterialName.setToolTipText("");
        jLabelMaterialName.setAlignmentX(0.5F);
        jLabelMaterialName.setBorder(new javax.swing.border.MatteBorder(null));

        jLabelQuantity.setBackground(new java.awt.Color(0, 0, 204));
        jLabelQuantity.setForeground(new java.awt.Color(255, 255, 255));
        jLabelQuantity.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelQuantity.setText("Supplier Id");
        jLabelQuantity.setToolTipText("");
        jLabelQuantity.setAlignmentX(0.5F);
        jLabelQuantity.setBorder(new javax.swing.border.MatteBorder(null));

        btnLogout.setText("Logout");
        btnLogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLogoutActionPerformed(evt);
            }
        });

        btnAddMaterial.setBackground(new java.awt.Color(0, 0, 153));
        btnAddMaterial.setForeground(new java.awt.Color(255, 255, 255));
        btnAddMaterial.setText("ADD");
        btnAddMaterial.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnAddMaterial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddMaterialActionPerformed(evt);
            }
        });

        btnUpdateMaterial.setBackground(new java.awt.Color(0, 0, 153));
        btnUpdateMaterial.setForeground(new java.awt.Color(255, 255, 255));
        btnUpdateMaterial.setText("UPDATE");
        btnUpdateMaterial.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnUpdateMaterial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateMaterialActionPerformed(evt);
            }
        });

        btnDeleteMaterial.setBackground(new java.awt.Color(0, 0, 153));
        btnDeleteMaterial.setForeground(new java.awt.Color(255, 255, 255));
        btnDeleteMaterial.setText("DELETE");
        btnDeleteMaterial.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnDeleteMaterial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteMaterialActionPerformed(evt);
            }
        });

        btnClearFields.setBackground(new java.awt.Color(0, 0, 153));
        btnClearFields.setForeground(new java.awt.Color(255, 255, 255));
        btnClearFields.setText("CLEAR");
        btnClearFields.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnClearFields.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearFieldsActionPerformed(evt);
            }
        });

        btnSearchMaterial.setBackground(new java.awt.Color(0, 0, 153));
        btnSearchMaterial.setForeground(new java.awt.Color(255, 255, 255));
        btnSearchMaterial.setText("SEARCH");
        btnSearchMaterial.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnSearchMaterial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchMaterialActionPerformed(evt);
            }
        });

        btnManageEmployees.setText("Manage Employees");
        btnManageEmployees.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                btnManageEmployeesActionPerformed(evt);
            }
        });
        btnManageOrders.setText("Manage Orders");
        btnManageOrders.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                btnManageOrderActionPerformed(evt);
            }
        });
        btnManageSuppliers.setText("Manage Suppliers");
        btnManageSuppliers.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                btnManageSupplierActionPerformed(evt);
            }
        });
        btnManageMaterials.setText("Manage Materials");
        btnManageMaterials.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                btnManageMaterialActionPerformed(evt);
            }
        });
        btnManageProducts.setText("Manage Products");
        btnManageProducts.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                btnManageProductsActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
                jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGap(37, 37, 37)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addGroup(jPanel4Layout.createSequentialGroup()
                                                .addComponent(btnSearchMaterial, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addGap(18, 18, 18)
                                                .addComponent(btnClearFields, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(jPanel4Layout.createSequentialGroup()
                                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                        .addComponent(jLabelQuantity, javax.swing.GroupLayout.DEFAULT_SIZE, 78, Short.MAX_VALUE)
                                                        .addComponent(jLabelMaterialName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                        .addComponent(jLabelMaterialID, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                                .addGap(18, 18, 18)
                                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addGroup(jPanel4Layout.createSequentialGroup()
                                                                .addComponent(txtMaterialID, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                .addGap(18, 18, 18)
                                                                .addComponent(btnAddMaterial, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                        .addGroup(jPanel4Layout.createSequentialGroup()
                                                                .addComponent(txtMaterialName, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                .addGap(18, 18, 18)
                                                                .addComponent(btnDeleteMaterial, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                        .addGroup(jPanel4Layout.createSequentialGroup()
                                                                .addComponent(txtQuantity, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                .addGap(18, 18, 18)
                                                                .addComponent(btnUpdateMaterial, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                .addContainerGap(66, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
                jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGap(24, 24, 24)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabelMaterialID, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(txtMaterialID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnAddMaterial))
                                .addGap(10, 10, 10)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabelMaterialName, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(txtMaterialName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnDeleteMaterial))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabelQuantity, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(txtQuantity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnUpdateMaterial))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(btnClearFields)
                                        .addComponent(btnSearchMaterial))
                                .addContainerGap(30, Short.MAX_VALUE))
        );

        jPanel5.setLayout(new BorderLayout());
        jScrollPane2.setViewportView(tableMaterials);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
                jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 600, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
                jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 427, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
                jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
                jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addContainerGap())
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addContainerGap())
        );

        pack();
    }

    private void refreshMaterialTable() {
        // Clear existing data from the table
        tableModel.setRowCount(0);

        // Retrieve all materials from the database
        List<Material> materials = materialController.getAllMaterialsFromDB();

        // Populate the table with the retrieved materials
        for (Material material : materials) {
            Object[] rowData = {material.getMaterialId(), material.getMaterialName(), material.getSupplierId()};
            tableModel.addRow(rowData);
        }
    }

    private void showMaterialsInTable() {
        String[] columnNames = {"Material ID", "Material Name", "Supplier Id"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);

        List<Material> materials = materialController.getAllMaterialsFromDB();
        for (Material material : materials) {
            Object[] rowData = {material.getMaterialId(), material.getMaterialName(), material.getSupplierId()};
            model.addRow(rowData);
        }

        tableMaterials.setModel(model); // Set the model for jTable1
        tableMaterials.setPreferredScrollableViewportSize(new Dimension(250, 100));
    }

    private void btnAddMaterialActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            String materialName = txtMaterialName.getText();
            int quantity = Integer.parseInt(txtQuantity.getText());

            if (!materialName.isEmpty() && quantity > 0) {
                Material material = new Material(materialName, quantity);
                boolean result = materialController.insertMaterialToDB(material);

                if (result) {
                    JOptionPane.showMessageDialog(rootPane, "Material added successfully", "Success", JOptionPane.INFORMATION_MESSAGE);
                    refreshMaterialTable();
                } else {
                    JOptionPane.showMessageDialog(rootPane, "Error adding material to the database", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(rootPane, "Please enter valid Material Name and Quantity", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(rootPane, "Invalid input format for Quantity", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void btnUpdateMaterialActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            int materialId = Integer.parseInt(txtMaterialID.getText());
            String materialName = txtMaterialName.getText();
            int quantity = Integer.parseInt(txtQuantity.getText());

            if (materialId > 0 && !materialName.isEmpty() && quantity > 0) {
                Material material = new Material(materialName, quantity);
                material.setMaterialId(materialId);
                boolean result = materialController.updateMaterialInDB(material);

                if (result) {
                    JOptionPane.showMessageDialog(rootPane, "Material updated successfully", "Success", JOptionPane.INFORMATION_MESSAGE);
                    refreshMaterialTable();
                } else {
                    JOptionPane.showMessageDialog(rootPane, "Error updating material in the database", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(rootPane, "Please enter valid Material ID, Material Name, and Quantity", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(rootPane, "Invalid input format for Material ID or Quantity", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void btnDeleteMaterialActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            int materialId = Integer.parseInt(txtMaterialID.getText());

            if (materialId > 0) {
                Material material = new Material("", 0);
                material.setMaterialId(materialId);
                boolean result = materialController.deleteMaterialFromDB(material);

                if (result) {
                    JOptionPane.showMessageDialog(rootPane, "Material deleted successfully", "Success", JOptionPane.INFORMATION_MESSAGE);
                    refreshMaterialTable();
                } else {
                    JOptionPane.showMessageDialog(rootPane, "Error deleting material from the database", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(rootPane, "Please enter a valid Material ID", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(rootPane, "Invalid input format for Material ID", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void btnSearchMaterialActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            int materialId = Integer.parseInt(txtMaterialID.getText());

            if (materialId > 0) {
                Material material = materialController.searchById(materialId);

                if (material != null) {
                    // Material found in the database, display its details in the text fields
                    txtMaterialName.setText(material.getMaterialName());
                    txtQuantity.setText(String.valueOf(material.getSupplierId()));
                    JOptionPane.showMessageDialog(rootPane, "Material found in the database", "Success", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    // Material not found in the database
                    JOptionPane.showMessageDialog(rootPane, "Material not found in the database", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(rootPane, "Please enter a valid Material ID", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(rootPane, "Invalid input format for Material ID", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void btnClearFieldsActionPerformed(java.awt.event.ActionEvent evt) {
        clearFields();
    }

    private void clearFields() {
        // Clear the text fields
        txtMaterialID.setText("");
        txtMaterialName.setText("");
        txtQuantity.setText("");
    }
    private void btnManageProductsActionPerformed(java.awt.event.ActionEvent evt) {
        // Create a new instance of EmployeeView
        ProductView productView = new ProductView();

        // Close the current EmployeeView
        this.dispose();

        // Display the new EmployeeView
        productView .setVisible(true);
    }
    private void btnManageEmployeesActionPerformed(java.awt.event.ActionEvent evt) {
        // Create a new instance of EmployeeView
        EmployeeView employeeView = new EmployeeView();

        // Close the current EmployeeView
        this.dispose();

        // Display the new EmployeeView
        employeeView.setVisible(true);
    }
    private void btnManageMaterialActionPerformed(java.awt.event.ActionEvent evt) {
        // Create a new instance of MaterialView
        MaterialView materialView = new MaterialView();

        // Close the current MaterialView
        this.dispose();

        // Display the new MaterialView
        materialView.setVisible(true);
    }

    private void btnManageOrderActionPerformed(java.awt.event.ActionEvent evt) {
        // Create a new instance of OrderView
        OrderView orderView = new OrderView();

        // Close the current MaterialView
        this.dispose();

        // Display the new OrderView
        orderView.setVisible(true);
    }

    private void btnManageSupplierActionPerformed(java.awt.event.ActionEvent evt) {
        // Create a new instance of SupplierView
        SupplierView supplierView = new SupplierView();

        // Close the current MaterialView
        this.dispose();

        // Display the new SupplierView
        supplierView.setVisible(true);
    }
    private void btnLogoutActionPerformed(java.awt.event.ActionEvent evt) {
        LoginView loginView = new LoginView();
        loginView.setVisible(true);
        this.setVisible(false);
    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MaterialView().setVisible(true);
            }
        });
    }

    // Variables declaration
    private javax.swing.JButton btnAddMaterial;
    private javax.swing.JButton btnClearFields;
    private javax.swing.JButton btnDeleteMaterial;
    private javax.swing.JButton btnManageEmployees;
    private javax.swing.JButton btnManageMaterials;
    private javax.swing.JButton btnManageOrders;
    private javax.swing.JButton btnManageProducts;
    private javax.swing.JButton btnManageSuppliers;
    private javax.swing.JButton btnMonthlyIncomeExpenseReport;
    private javax.swing.JButton btnSearchMaterial;
    private javax.swing.JButton btnUpdateMaterial;
    private javax.swing.JButton btnAllocateE2O;
    private javax.swing.JButton btnLogout;
    private javax.swing.JLabel jLabelMaterialID;
    private javax.swing.JLabel jLabelMaterialName;
    private javax.swing.JLabel jLabelQuantity;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField txtMaterialID;
    private javax.swing.JTextField txtMaterialName;
    private javax.swing.JTextField txtQuantity;
}
