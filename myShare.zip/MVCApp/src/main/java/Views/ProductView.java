package Views;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import Controllers.ProductController;
import Models.Product;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.List;

public class ProductView extends javax.swing.JFrame {

    Product objProduct;
    ProductController productController;
    DefaultTableModel tableModel;
    JTable tableProducts;

    public ProductView() {
        initComponents();
        productController = new ProductController();
        tableModel = new DefaultTableModel();
        tableModel.addColumn("Product ID");
        tableModel.addColumn("Product Name");
        tableModel.addColumn("Price");
        tableProducts = new JTable(tableModel);
        jScrollPane2.setViewportView(tableProducts);
        refreshProductTable();
    }

    private void initComponents() {
        jPanel1 = new javax.swing.JPanel();
        btnManageOrders = new javax.swing.JButton();
        btnManageSuppliers = new javax.swing.JButton();
        btnManageEmployees = new javax.swing.JButton();
        btnManageProducts = new javax.swing.JButton();
        btnManageMaterials = new javax.swing.JButton();
        btnAllocateE2O = new javax.swing.JButton();
        btnMonthlyIncomeExpenseReport = new javax.swing.JButton();
        btnLogout = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jLabelProductID = new javax.swing.JLabel();
        jLabelProductName = new javax.swing.JLabel();
        jLabelPrice = new javax.swing.JLabel();
        txtProductID = new javax.swing.JTextField();
        txtProductName = new javax.swing.JTextField();
        txtPrice = new javax.swing.JTextField();
        btnAddProduct = new javax.swing.JButton();
        btnUpdateProduct = new javax.swing.JButton();
        btnDeleteProduct = new javax.swing.JButton();
        btnClearFields = new javax.swing.JButton();
        btnSearchProduct = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tableProducts = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(153, 153, 255));

        jPanel1.setBackground(new java.awt.Color(51, 51, 255));
        jPanel2.setBackground(new java.awt.Color(153, 153, 255));

        jPanel4.setBackground(new java.awt.Color(153, 153, 255));
        jPanel4.setForeground(new java.awt.Color(255, 255, 255));

        // Add other buttons and action listeners for jPanel1

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(btnManageOrders, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnManageSuppliers, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnManageEmployees, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnManageProducts, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnManageMaterials, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnAllocateE2O, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnMonthlyIncomeExpenseReport)
                                        .addComponent(btnLogout))
                                .addGap(0, 21, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(49, 49, 49)
                                .addComponent(btnManageOrders)
                                .addGap(18, 18, 18)
                                .addComponent(btnManageSuppliers)
                                .addGap(18, 18, 18)
                                .addComponent(btnManageEmployees)
                                .addGap(18, 18, 18)
                                .addComponent(btnManageProducts)
                                .addGap(18, 18, 18)
                                .addComponent(btnManageMaterials)
                                .addGap(18, 18, 18)
                                .addComponent(btnAllocateE2O)
                                .addGap(18, 18, 18)
                                .addComponent(btnMonthlyIncomeExpenseReport)
                                .addGap(29, 29, 29)
                                .addComponent(btnLogout)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.setBackground(new java.awt.Color(153, 153, 255));

        jPanel4.setBackground(new java.awt.Color(153, 153, 255));
        jPanel4.setForeground(new java.awt.Color(255, 255, 255));

        jLabelProductID.setBackground(new java.awt.Color(0, 0, 204));
        jLabelProductID.setForeground(new java.awt.Color(255, 255, 255));
        jLabelProductID.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelProductID.setText("Product ID");
        jLabelProductID.setToolTipText("");
        jLabelProductID.setAlignmentX(0.5F);
        jLabelProductID.setBorder(new javax.swing.border.MatteBorder(null));

        jLabelProductName.setBackground(new java.awt.Color(0, 0, 204));
        jLabelProductName.setForeground(new java.awt.Color(255, 255, 255));
        jLabelProductName.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelProductName.setText("Product Name");
        jLabelProductName.setToolTipText("");
        jLabelProductName.setAlignmentX(0.5F);
        jLabelProductName.setBorder(new javax.swing.border.MatteBorder(null));

        jLabelPrice.setBackground(new java.awt.Color(0, 0, 204));
        jLabelPrice.setForeground(new java.awt.Color(255, 255, 255));
        jLabelPrice.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelPrice.setText("Price");
        jLabelPrice.setToolTipText("");
        jLabelPrice.setAlignmentX(0.5F);
        jLabelPrice.setBorder(new javax.swing.border.MatteBorder(null));

        btnLogout.setText("Logout");
        btnLogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLogoutActionPerformed(evt);
            }
        });

        btnAddProduct.setBackground(new java.awt.Color(0, 0, 153));
        btnAddProduct.setForeground(new java.awt.Color(255, 255, 255));
        btnAddProduct.setText("ADD");
        btnAddProduct.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnAddProduct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddProductActionPerformed(evt);
            }
        });

        btnUpdateProduct.setBackground(new java.awt.Color(0, 0, 153));
        btnUpdateProduct.setForeground(new java.awt.Color(255, 255, 255));
        btnUpdateProduct.setText("UPDATE");
        btnUpdateProduct.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnUpdateProduct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateProductActionPerformed(evt);
            }
        });

        btnDeleteProduct.setBackground(new java.awt.Color(0, 0, 153));
        btnDeleteProduct.setForeground(new java.awt.Color(255, 255, 255));
        btnDeleteProduct.setText("DELETE");
        btnDeleteProduct.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnDeleteProduct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteProductActionPerformed(evt);
            }
        });

        btnClearFields.setBackground(new java.awt.Color(0, 0, 153));
        btnClearFields.setForeground(new java.awt.Color(255, 255, 255));
        btnClearFields.setText("CLEAR");
        btnClearFields.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnClearFields.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearFieldsActionPerformed(evt);
            }
        });

        btnSearchProduct.setBackground(new java.awt.Color(0, 0, 153));
        btnSearchProduct.setForeground(new java.awt.Color(255, 255, 255));
        btnSearchProduct.setText("SEARCH");
        btnSearchProduct.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnSearchProduct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchProductActionPerformed(evt);
            }
        });

        btnLogout.setText("Logout");
        btnLogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLogoutActionPerformed(evt);
            }
        });

        btnManageEmployees.setText("Manage Employees");
        btnManageEmployees.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                btnManageEmployeesActionPerformed(evt);
            }
        });
        btnManageOrders.setText("Manage Orders");
        btnManageOrders.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                btnManageOrderActionPerformed(evt);
            }
        });
        btnManageSuppliers.setText("Manage Suppliers");
        btnManageSuppliers.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                btnManageSupplierActionPerformed(evt);
            }
        });
        btnManageMaterials.setText("Manage Materials");
        btnManageMaterials.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                btnManageMaterialActionPerformed(evt);
            }
        });

        btnManageProducts.setText("Manage Products");
        btnManageProducts.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                btnManageProductsActionPerformed(evt);
            }
        });


        jScrollPane2.setViewportView(tableProducts);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
                jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 600, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
                jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 427, Short.MAX_VALUE)
        );
        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
                jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(19, 19, 19)
                                .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addContainerGap())
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addContainerGap()
                                        .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addContainerGap()))
        );
        jPanel2Layout.setVerticalGroup(
                jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addGap(0, 140, Short.MAX_VALUE)
                                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addContainerGap()
                                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
                jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGap(37, 37, 37)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addGroup(jPanel4Layout.createSequentialGroup()
                                                .addComponent(btnSearchProduct, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addGap(18, 18, 18)
                                                .addComponent(btnClearFields, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(jPanel4Layout.createSequentialGroup()
                                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                        .addComponent(jLabelPrice, javax.swing.GroupLayout.DEFAULT_SIZE, 110, Short.MAX_VALUE)
                                                        .addComponent(jLabelProductName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                        .addComponent(jLabelProductID, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                                .addGap(18, 18, 18)
                                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addGroup(jPanel4Layout.createSequentialGroup()
                                                                .addComponent(txtProductID, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                .addGap(18, 18, 18)
                                                                .addComponent(btnAddProduct, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                        .addGroup(jPanel4Layout.createSequentialGroup()
                                                                .addComponent(txtProductName, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                .addGap(18, 18, 18)
                                                                .addComponent(btnDeleteProduct, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                        .addGroup(jPanel4Layout.createSequentialGroup()
                                                                .addComponent(txtPrice, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                .addGap(18, 18, 18)
                                                                .addComponent(btnUpdateProduct, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                .addContainerGap(66, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
                jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGap(24, 24, 24)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabelProductID, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(txtProductID, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnAddProduct, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabelProductName, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(txtProductName, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnDeleteProduct, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabelPrice, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(txtPrice, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnUpdateProduct, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(btnSearchProduct, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnClearFields, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addContainerGap(22, Short.MAX_VALUE))
        );

        // jPanel5: ScrollPane for the Table
        jPanel5.setBackground(new java.awt.Color(153, 153, 255));
        jPanel5.setLayout(new BorderLayout());

        jScrollPane2.setViewportView(tableProducts);
        jPanel5.add(jScrollPane2, BorderLayout.CENTER);

        // Main layout
        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addContainerGap())
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addContainerGap())
        );

        pack();

    }

    private void refreshProductTable() {
        tableModel.setRowCount(0);

        List<Product> products = productController.getAllProductsFromDB();

        for (Product product : products) {
            Object[] rowData = {product.getProductId(), product.getProductName(), product.getPrice()};
            tableModel.addRow(rowData);
        }
    }

    private void showProductsInTable() {
        String[] columnNames = {"Product ID", "Product Name", "Price"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);

        List<Product> products = productController.getAllProductsFromDB();
        for (Product product : products) {
            Object[] rowData = {product.getProductId(), product.getProductName(), product.getPrice()};
            model.addRow(rowData);
        }

        tableProducts.setModel(model);
        tableProducts.setPreferredScrollableViewportSize(new Dimension(250, 100));
    }

    private void btnAddProductActionPerformed(ActionEvent evt) {
        try {
            String productName = txtProductName.getText();
            double price = Double.parseDouble(txtPrice.getText());

            if (!productName.isEmpty() && price > 0) {
                Product product = new Product(productName, price);
                boolean result = productController.insertProductToDB(product);

                if (result) {
                    JOptionPane.showMessageDialog(rootPane, "Product added successfully", "Success", JOptionPane.INFORMATION_MESSAGE);
                    refreshProductTable();
                } else {
                    JOptionPane.showMessageDialog(rootPane, "Error adding product to the database", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(rootPane, "Please enter valid Product Name and Price", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(rootPane, "Invalid input format for Price", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void btnUpdateProductActionPerformed(ActionEvent evt) {
        try {
            int productId = Integer.parseInt(txtProductID.getText());
            String productName = txtProductName.getText();
            double price = Double.parseDouble(txtPrice.getText());

            if (productId > 0 && !productName.isEmpty() && price > 0) {
                Product product = new Product(productName, price);
                product.setProductId(productId);
                boolean result = productController.updateProductInDB(product);

                if (result) {
                    JOptionPane.showMessageDialog(rootPane, "Product updated successfully", "Success", JOptionPane.INFORMATION_MESSAGE);
                    refreshProductTable();
                } else {
                    JOptionPane.showMessageDialog(rootPane, "Error updating product in the database", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(rootPane, "Please enter valid Product ID, Product Name, and Price", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(rootPane, "Invalid input format for Product ID or Price", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void btnDeleteProductActionPerformed(ActionEvent evt) {
        try {
            int productId = Integer.parseInt(txtProductID.getText());

            if (productId > 0) {
                Product product = new Product("", 0);
                product.setProductId(productId);
                boolean result = productController.deleteProductFromDB(product);

                if (result) {
                    JOptionPane.showMessageDialog(rootPane, "Product deleted successfully", "Success", JOptionPane.INFORMATION_MESSAGE);
                    refreshProductTable();
                } else {
                    JOptionPane.showMessageDialog(rootPane, "Error deleting product from the database", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(rootPane, "Please enter a valid Product ID", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(rootPane, "Invalid input format for Product ID", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void btnSearchProductActionPerformed(ActionEvent evt) {
        try {
            int productId = Integer.parseInt(txtProductID.getText());

            if (productId > 0) {
                Product product = productController.searchByProductId(productId);

                if (product != null) {
                    txtProductName.setText(product.getProductName());
                    txtPrice.setText(Double.toString(product.getPrice()));
                    JOptionPane.showMessageDialog(rootPane, "Product found in the database", "Success", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(rootPane, "Product not found in the database", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(rootPane, "Please enter a valid Product ID", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(rootPane, "Invalid input format for Product ID", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void btnClearFieldsActionPerformed(ActionEvent evt) {
        clearFields();
    }

    private void clearFields() {
        txtProductID.setText("");
        txtProductName.setText("");
        txtPrice.setText("");
    }

    private void btnManageProductsActionPerformed(java.awt.event.ActionEvent evt) {
        // Create a new instance of EmployeeView
        ProductView productView = new ProductView();

        // Close the current EmployeeView
        this.dispose();

        // Display the new EmployeeView
        productView .setVisible(true);
    }

    private void btnManageEmployeesActionPerformed(java.awt.event.ActionEvent evt) {
        // Create a new instance of EmployeeView
        EmployeeView employeeView = new EmployeeView();

        // Close the current EmployeeView
        this.dispose();

        // Display the new EmployeeView
        employeeView.setVisible(true);
    }
    private void btnManageOrderActionPerformed(java.awt.event.ActionEvent evt) {
        // Create a new instance of OrderView
        OrderView orderView = new OrderView();

        // Close the current OrderView
        this.dispose();

        // Display the new OrderView
        orderView.setVisible(true);
    }
    private void btnManageSupplierActionPerformed(java.awt.event.ActionEvent evt) {
        // Create a new instance of OrderView
        SupplierView supplierView = new SupplierView();

        // Close the current OrderView
        this.dispose();

        // Display the new OrderView
        supplierView.setVisible(true);
    }
    private void btnManageMaterialActionPerformed(java.awt.event.ActionEvent evt) {
        // Create a new instance of OrderView
        MaterialView materialView = new MaterialView();

        // Close the current OrderView
        this.dispose();

        // Display the new OrderView
        materialView.setVisible(true);
    }
    private void btnLogoutActionPerformed(ActionEvent evt) {
        LoginView loginView = new LoginView();
        loginView.setVisible(true);
        this.setVisible(false);
    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ProductView().setVisible(true);
            }
        });
    }

    // Variables declaration
    private javax.swing.JButton btnAddProduct;
    private javax.swing.JButton btnClearFields;
    private javax.swing.JButton btnDeleteProduct;
    private javax.swing.JButton btnSearchProduct;
    private javax.swing.JButton btnUpdateProduct;
    private javax.swing.JButton btnDeleteEmployee;
    private javax.swing.JButton btnManageEmployees;
    private javax.swing.JButton btnManageSuppliers;
    private javax.swing.JButton btnManageProducts;
    private javax.swing.JButton btnManageOrders;
    private javax.swing.JButton btnManageMaterials;
    private javax.swing.JButton btnSearchEmployee;
    private javax.swing.JButton btnUpdateEmployee;
    private javax.swing.JButton btnAllocateE2O;
    private javax.swing.JButton btnMonthlyIncomeExpenseReport;

    private javax.swing.JButton btnLogout;
    private javax.swing.JLabel jLabelPrice;
    private javax.swing.JLabel jLabelProductName;
    private javax.swing.JLabel jLabelProductID;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField txtProductID;
    private javax.swing.JTextField txtProductName;
    private javax.swing.JTextField txtPrice;
}
