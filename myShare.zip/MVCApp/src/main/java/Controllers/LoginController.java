package Controllers;

import Models.Login;
import java.util.ArrayList;

public class LoginController {

    Login LoginObj;
    ArrayList<Login> LoginDB;

    public LoginController()
    {
        LoginDB = new ArrayList<>();
        LoginDB.add(new Login("admin","123"));
        LoginDB.add(new Login("user","abcd"));
    }

    public Login AddLoginUser(String EID, String Password)
    {
        LoginObj = new Login(EID, Password);
        return LoginObj;
    }

    public Login CheckUser(Login LoginObj)
    {
        for(Login Log:LoginDB)
        {
            if(LoginObj.getEID().equals(Log.getEID()) && LoginObj.getPassword().equals(Log.getPassword()))
            {
                return Log;
            }
        }
        return null;
    }
}
