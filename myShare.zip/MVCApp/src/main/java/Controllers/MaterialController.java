package Controllers;

import Models.Material;
import DatabaseAccessLayer.MaterialAccessLogic;
import java.util.ArrayList;
import java.util.List;

public class MaterialController {

    Material objMaterial;
    MaterialAccessLogic materialAccessLogic;

    public MaterialController() {
        materialAccessLogic = new MaterialAccessLogic();
    }

    public Material addMaterial(String materialName, int supplierId) {
        objMaterial = new Material(materialName, supplierId);
        return objMaterial;
    }

    public boolean insertMaterialToDB(Material material) {
        boolean result = materialAccessLogic.addMaterialToDB(material);
        return result;
    }

    public boolean updateMaterialInDB(Material material) {
        boolean result = materialAccessLogic.updateMaterialInDB(material);
        return result;
    }

    public boolean deleteMaterialFromDB(Material material) {
        boolean result = materialAccessLogic.deleteMaterialFromDB(material);
        return result;
    }

    public Material searchById(int materialId) {
        return materialAccessLogic.searchByIdFromDB(materialId);
    }

    public List<Material> getAllMaterialsFromDB() {
        List<Material> materials = new ArrayList<>();
        List<Object[]> rows = materialAccessLogic.getAllMaterialsFromDB();

        for (Object[] row : rows) {
            int materialId = (int) row[0];
            String materialName = (String) row[1];
            int supplierId = (int) row[2];
            Material material = new Material(materialName, supplierId);
            material.setMaterialId(materialId);
            materials.add(material);
        }

        return materials;
    }
}

