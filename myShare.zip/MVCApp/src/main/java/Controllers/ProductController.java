package Controllers;

import Models.Product;
import DatabaseAccessLayer.ProductAccessLogic;
import java.util.ArrayList;
import java.util.List;

public class ProductController {

    Product objProduct;
    ProductAccessLogic productAccessLogic;

    public ProductController() {
        productAccessLogic = new ProductAccessLogic();
    }

    public Product addProduct(int productId, String productName, double price) {
        objProduct = new Product(productId, productName, price);
        return objProduct;
    }

    public boolean insertProductToDB(Product product) {
        boolean result = productAccessLogic.addProductToDB(product);
        return result;
    }

    public boolean updateProductInDB(Product product) {
        boolean result = productAccessLogic.updateProductInDB(product);
        return result;
    }

    public boolean deleteProductFromDB(Product product) {
        boolean result = productAccessLogic.deleteProductFromDB(product);
        return result;
    }

    public Product searchByProductId(int productId) {
        return productAccessLogic.searchByProductIdFromDB(productId);
    }

    public List<Product> getAllProductsFromDB() {
        List<Product> products = new ArrayList<>();
        List<Object[]> rows = productAccessLogic.getAllProductsFromDB();

        for (Object[] row : rows) {
            int productId = (int) row[0];
            String productName = (String) row[1];
            double price = (double) row[2];
            Product product = new Product(productId, productName, price);
            products.add(product);
        }

        return products;
    }
}
