package Controllers;

import Models.Order;
import DatabaseAccessLayer.OrderAccessLogic;
import java.util.ArrayList;
import java.util.List;
public class OrderController {

    Order objOrder;
    OrderAccessLogic orderAccessLogic;

    public OrderController() {
        orderAccessLogic = new OrderAccessLogic();
    }

    public Order addOrder(int customerId, int productId) {
        objOrder = new Order(customerId, productId);
        return objOrder;
    }

    public boolean insertOrderToDB(Order order) {
        boolean result = orderAccessLogic.addOrderToDB(order);
        return result;
    }

    public boolean updateOrderInDB(Order order) {
        boolean result = orderAccessLogic.updateOrderInDB(order);
        return result;
    }

    public boolean deleteOrderFromDB(Order order) {
        boolean result = orderAccessLogic.deleteOrderFromDB(order);
        return result;
    }

    public Order searchById(int orderId) {
        return orderAccessLogic.searchByIdFromDB(orderId);
    }

    public List<Order> getAllOrdersFromDB() {
        List<Order> orders = new ArrayList<>();
        List<Object[]> rows = orderAccessLogic.getAllOrdersFromDB();

        for (Object[] row : rows) {
            int orderId = (int) row[0];
            int customerId = (int) row[1];
            int productId = (int) row[2];
            Order order = new Order(customerId, productId);
            order.setOrderId(orderId);
            orders.add(order);
        }

        return orders;
    }
}
