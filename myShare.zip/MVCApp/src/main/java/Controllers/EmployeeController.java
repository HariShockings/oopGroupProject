package Controllers;

import Models.Employee;
import DatabaseAccessLayer.EmployeeAccessLogic;
import java.util.ArrayList;
import java.util.List;

public class EmployeeController {

    private Employee objEmployee;
    private EmployeeAccessLogic employeeAccessLogic;

    public EmployeeController() {
        employeeAccessLogic = new EmployeeAccessLogic();
    }

    public Employee addEmployee(int employeeId, String employeeName) {
        objEmployee = new Employee(employeeId, employeeName);
        return objEmployee;
    }

    public boolean insertEmployeeToDB(Employee employee) {
        boolean result = employeeAccessLogic.addEmployeeToDB(employee);
        return result;
    }

    public boolean updateEmployeeInDB(Employee employee) {
        boolean result = employeeAccessLogic.updateEmployeeInDB(employee);
        return result;
    }

    public boolean deleteEmployeeFromDB(Employee employee) {
        boolean result = employeeAccessLogic.deleteEmployeeFromDB(employee);
        return result;
    }

    public Employee searchByEmployeeId(int employeeId) {
        return employeeAccessLogic.searchByEmployeeIdFromDB(employeeId);
    }

    public List<Employee> getAllEmployeesFromDB() {
        List<Employee> employees = new ArrayList<>();
        List<Object[]> rows = employeeAccessLogic.getAllEmployeesFromDB();

        for (Object[] row : rows) {
            int employeeId = (int) row[0];
            String employeeName = (String) row[1];
            Employee employee = new Employee(employeeId, employeeName);
            employee.setEmployeeId(employeeId);
            employees.add(employee);
        }

        return employees;
    }
}
