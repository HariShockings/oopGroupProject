package Controllers;

import Models.Supplier;
import DatabaseAccessLayer.SupplierAccessLogic;
import java.util.ArrayList;
import java.util.List;
public class SupplierController {

    Supplier objSupplier;
    SupplierAccessLogic supplierAccessLogic;

    public SupplierController() {
        supplierAccessLogic = new SupplierAccessLogic();
    }

    public Supplier addSupplier(int supplierID, String supplierName) {
        objSupplier = new Supplier(supplierID, supplierName);
        return objSupplier;
    }

    public boolean insertSupplierToDB(Supplier supplier) {
        boolean result = supplierAccessLogic.addSupplierToDB(supplier);
        return result;
    }

    public boolean updateSupplierInDB(Supplier supplier) {
        boolean result = supplierAccessLogic.updateSupplierInDB(supplier);
        return result;
    }

    public boolean deleteSupplierFromDB(Supplier supplier) {
        boolean result = supplierAccessLogic.deleteSupplierFromDB(supplier);
        return result;
    }

    public Supplier searchBySupplierId(int supplierId) {
        return supplierAccessLogic.searchBySupplierIdFromDB(supplierId);
    }

    public List<Supplier> getAllSupplierFromDB() {
        List<Supplier> suppliers = new ArrayList<>();
        List<Object[]> rows = supplierAccessLogic.getAllSuppliersFromDB();

        for (Object[] row : rows) {
            int supplierId = (int) row[0];
            String supplierName = (String) row[1];
            Supplier supplier = new Supplier(supplierId, supplierName);
            supplier.getSupplierId(supplierId);
            suppliers.add(supplier);
        }

        return suppliers;
    }
}
