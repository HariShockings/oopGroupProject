package DatabaseAccessLayer;

import DatabaseLayer.DatabaseConnection;
import Models.Order;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class OrderAccessLogic {

    private DatabaseConnection singleConn;

    public OrderAccessLogic() {
        singleConn = DatabaseConnection.getSingleInstance();
    }

    public boolean addOrderToDB(Order order) {
        try {
            String query = "INSERT INTO orders (customer_id, product_id) VALUES ('" + order.getCustomerId() + "', '" + order.getProductId() + "')";
            boolean result = singleConn.ExecuteQuery(query);
            return result;
        } catch (Exception ex) {
            return false;
        }
    }

    public boolean updateOrderInDB(Order order) {
        try {
            String query = "UPDATE orders SET product_id = '" + order.getProductId() + "',customer_id = '" + order.getCustomerId() + "' WHERE order_id = '" + order.getOrderId() + "'";
            boolean result = singleConn.ExecuteQuery(query);
            return result;
        } catch (Exception ex) {
            return false;
        }
    }

    public boolean deleteOrderFromDB(Order order) {
        try {
            String query = "DELETE FROM orders WHERE order_id = '" + order.getOrderId() + "'";
            boolean result = singleConn.ExecuteQuery(query);
            return result;
        } catch (Exception ex) {
            return false;
        }
    }

    public Order searchByIdFromDB(int orderId) {
        try {
            String query = "SELECT * FROM orders WHERE order_id = '" + orderId + "'";
            ResultSet rs = singleConn.ExecuteResultSet(query);

            if (rs.next()) {
                int customerId = rs.getInt("customer_id");
                int productId = rs.getInt("product_id");
                Order order = new Order(customerId, productId);
                order.setOrderId(orderId);
                return order;
            } else {
                return null;
            }
        } catch (Exception ex) {
            return null;
        }
    }

    public List<Object[]> getAllOrdersFromDB() {
        List<Object[]> orders = new ArrayList<>();
        try {
            String query = "SELECT * FROM orders";
            ResultSet rs = singleConn.ExecuteQueryWithResult(query);
            while (rs.next()) {
                int orderId = rs.getInt("order_id");
                int customerId = rs.getInt("customer_id");
                int productId = rs.getInt("product_id");
                Object[] row = {orderId, customerId, productId};
                orders.add(row);
            }
            rs.close();
        } catch (SQLException ex) {
            System.out.println("Error fetching orders from the database: " + ex.getMessage());
        }
        return orders;
    }
}
