package DatabaseAccessLayer;

import DatabaseLayer.DatabaseConnection;
import Models.Supplier;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class SupplierAccessLogic {

    private DatabaseConnection singleConn;

    public SupplierAccessLogic() {
        singleConn = DatabaseConnection.getSingleInstance();
    }

    public boolean addSupplierToDB(Supplier supplier) {
        try {
            String query = "INSERT INTO suppliers (supplier_name) VALUES ('" + supplier.getSupplierName() + "')";
            boolean result = singleConn.ExecuteQuery(query);
            return result;
        } catch (Exception ex) {
            return false;
        }
    }

    public boolean updateSupplierInDB(Supplier supplier) {
        try {
            String query = "UPDATE suppliers SET supplier_id = '" + supplier.getSupplierId() + "',supplier_name = '" + supplier.getSupplierName() + "' WHERE supplier_id = '" + supplier.getSupplierId() + "'";
            boolean result = singleConn.ExecuteQuery(query);
            return result;
        } catch (Exception ex) {
            return false;
        }
    }

    public boolean deleteSupplierFromDB(Supplier supplier) {
        try {
            String query = "DELETE FROM suppliers WHERE supplier_id = '" + supplier.getSupplierId() + "'";
            boolean result = singleConn.ExecuteQuery(query);
            return result;
        } catch (Exception ex) {
            return false;
        }
    }

    public Supplier searchBySupplierIdFromDB(int supplierId) {
        try {
            String query = "SELECT * FROM suppliers WHERE supplier_id = '" + supplierId + "'";
            ResultSet rs = singleConn.ExecuteResultSet(query);

            if (rs.next()) {
                String supplierName = rs.getString("supplier_name");
                Supplier supplier = new Supplier(supplierId, supplierName);
                return supplier;
            } else {
                return null;
            }
        } catch (Exception ex) {
            return null;
        }
    }

    public List<Object[]> getAllSuppliersFromDB() {
        List<Object[]> suppliers = new ArrayList<>();
        try {
            String query = "SELECT * FROM suppliers";
            ResultSet rs = singleConn.ExecuteResultSet(query);
            while (rs.next()) {
                int supplierId = rs.getInt("supplier_id");
                String supplierName = rs.getString("supplier_name");
                Object[] row = {supplierId, supplierName};
                suppliers.add(row);
            }
            rs.close();
        } catch (SQLException ex) {
            System.out.println("Error fetching suppliers from the database: " + ex.getMessage());
        }
        return suppliers;
    }
}
