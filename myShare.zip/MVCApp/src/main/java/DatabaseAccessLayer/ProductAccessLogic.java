package DatabaseAccessLayer;

import DatabaseLayer.DatabaseConnection;
import Models.Product;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProductAccessLogic {

    private DatabaseConnection singleConn;

    public ProductAccessLogic() {
        singleConn = DatabaseConnection.getSingleInstance();
    }

    public boolean addProductToDB(Product product) {
        try {
            String query = "INSERT INTO products (product_name, price) VALUES ('" + product.getProductName() + "', " + product.getPrice() + ")";
            boolean result = singleConn.ExecuteQuery(query);
            return result;
        } catch (Exception ex) {
            return false;
        }
    }

    public boolean updateProductInDB(Product product) {
        try {
            String query = "UPDATE products SET product_name = '" + product.getProductName() + "', price = " + product.getPrice() + " WHERE product_id = " + product.getProductId();
            boolean result = singleConn.ExecuteQuery(query);
            return result;
        } catch (Exception ex) {
            return false;
        }
    }

    public boolean deleteProductFromDB(Product product) {
        try {
            String query = "DELETE FROM products WHERE product_id = " + product.getProductId();
            boolean result = singleConn.ExecuteQuery(query);
            return result;
        } catch (Exception ex) {
            return false;
        }
    }

    public Product searchByProductIdFromDB(int productId) {
        try {
            String query = "SELECT * FROM products WHERE product_id = " + productId;
            ResultSet rs = singleConn.ExecuteResultSet(query);

            if (rs.next()) {
                String productName = rs.getString("product_name");
                double price = rs.getDouble("price");
                Product product = new Product(productId, productName, price);
                return product;
            } else {
                return null;
            }
        } catch (Exception ex) {
            return null;
        }
    }

    public List<Object[]> getAllProductsFromDB() {
        List<Object[]> products = new ArrayList<>();
        try {
            String query = "SELECT * FROM products";
            ResultSet rs = singleConn.ExecuteResultSet(query);
            while (rs.next()) {
                int productId = rs.getInt("product_id");
                String productName = rs.getString("product_name");
                double price = rs.getDouble("price");
                Object[] row = {productId, productName, price};
                products.add(row);
            }
            rs.close();
        } catch (SQLException ex) {
            System.out.println("Error fetching products from the database: " + ex.getMessage());
        }
        return products;
    }
}
