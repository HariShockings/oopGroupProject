package DatabaseAccessLayer;

import DatabaseLayer.DatabaseConnection;
import Models.Employee;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class EmployeeAccessLogic {

    private DatabaseConnection singleConn;

    public EmployeeAccessLogic() {
        singleConn = DatabaseConnection.getSingleInstance();
    }

    public boolean addEmployeeToDB(Employee employee) {
        try {
            String query = "INSERT INTO employees (employee_name) VALUES ('" + employee.getEmployeeName() + "')";
            boolean result = singleConn.ExecuteQuery(query);
            return result;
        } catch (Exception ex) {
            return false;
        }
    }

    public boolean updateEmployeeInDB(Employee employee) {
        try {
            String query = "UPDATE employees SET employee_id = '" + employee.getEmployeeId() + "', employee_name = '" + employee.getEmployeeName() + "' WHERE employee_id = '" + employee.getEmployeeId() + "'";
            boolean result = singleConn.ExecuteQuery(query);
            return result;
        } catch (Exception ex) {
            return false;
        }
    }

    public boolean deleteEmployeeFromDB(Employee employee) {
        try {
            String query = "DELETE FROM employees WHERE employee_id = '" + employee.getEmployeeId() + "'";
            boolean result = singleConn.ExecuteQuery(query);
            return result;
        } catch (Exception ex) {
            return false;
        }
    }

    public Employee searchByEmployeeIdFromDB(int employeeId) {
        try {
            String query = "SELECT * FROM employees WHERE employee_id = '" + employeeId + "'";
            ResultSet rs = singleConn.ExecuteResultSet(query);

            if (rs.next()) {
                String employeeName = rs.getString("employee_name");
                Employee employee = new Employee(employeeId, employeeName);
                return employee;
            } else {
                return null;
            }
        } catch (Exception ex) {
            return null;
        }
    }

    public List<Object[]> getAllEmployeesFromDB() {
        List<Object[]> employees = new ArrayList<>();
        try {
            String query = "SELECT * FROM employees";
            ResultSet rs = singleConn.ExecuteResultSet(query);
            while (rs.next()) {
                int employeeId = rs.getInt("employee_id");
                String employeeName = rs.getString("employee_name");
                Object[] row = {employeeId, employeeName};
                employees.add(row);
            }
            rs.close();
        } catch (SQLException ex) {
            System.out.println("Error fetching employees from the database: " + ex.getMessage());
        }
        return employees;
    }
}
