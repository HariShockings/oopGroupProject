package DatabaseAccessLayer;

import DatabaseLayer.DatabaseConnection;
import Models.Material;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MaterialAccessLogic {

    private DatabaseConnection singleConn;

    public MaterialAccessLogic() {
        singleConn = DatabaseConnection.getSingleInstance();
    }

    public boolean addMaterialToDB(Material material) {
        try {
            String query = "INSERT INTO materials (material_name, supplier_id) VALUES ('" + material.getMaterialName() + "', '" + material.getSupplierId() + "')";
            boolean result = singleConn.ExecuteQuery(query);
            return result;
        } catch (Exception ex) {
            return false;
        }
    }

    public boolean updateMaterialInDB(Material material) {
        try {
            String query = "UPDATE materials SET material_name = '" + material.getMaterialName() + "', supplier_id = '" + material.getSupplierId() + "' WHERE material_id = '" + material.getMaterialId() + "'";
            boolean result = singleConn.ExecuteQuery(query);
            return result;
        } catch (Exception ex) {
            return false;
        }
    }

    public boolean deleteMaterialFromDB(Material material) {
        try {
            String query = "DELETE FROM materials WHERE material_id = '" + material.getMaterialId() + "'";
            boolean result = singleConn.ExecuteQuery(query);
            return result;
        } catch (Exception ex) {
            return false;
        }
    }

    public Material searchByIdFromDB(int materialId) {
        try {
            String query = "SELECT * FROM materials WHERE material_id = '" + materialId + "'";
            ResultSet rs = singleConn.ExecuteResultSet(query);

            if (rs.next()) {
                String materialName = rs.getString("material_name");
                int supplierId = rs.getInt("supplier_id");
                Material material = new Material(materialName, supplierId);
                material.setMaterialId(materialId);
                return material;
            } else {
                return null;
            }
        } catch (Exception ex) {
            return null;
        }
    }

    public List<Object[]> getAllMaterialsFromDB() {
        List<Object[]> materials = new ArrayList<>();
        try {
            String query = "SELECT * FROM materials";
            ResultSet rs = singleConn.ExecuteQueryWithResult(query);
            while (rs.next()) {
                int materialId = rs.getInt("material_id");
                String materialName = rs.getString("material_name");
                int supplierId = rs.getInt("supplier_id");
                Object[] row = {materialId, materialName, supplierId};
                materials.add(row);
            }
            rs.close();
        } catch (SQLException ex) {
            System.out.println("Error fetching materials from the database: " + ex.getMessage());
        }
        return materials;
    }
}
