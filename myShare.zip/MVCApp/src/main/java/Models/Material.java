package Models;

public class Material {
    private int materialId;
    private String materialName;
    private int supplierId;

    public Material(String materialName, int supplierId) {
        this.materialName = materialName;
        this.supplierId = supplierId;
    }

    public int getMaterialId() {
        return materialId;
    }

    public void setMaterialId(int materialId) {
        this.materialId = materialId;
    }

    public String getMaterialName() {
        return materialName;
    }

    public void setMaterialName(String materialName) {
        this.materialName = materialName;
    }

    public int getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(int supplierId) {
        this.supplierId = supplierId;
    }

    @Override
    public String toString() {
        return "Material ID: " + materialId + ", Material Name: " + materialName + ", Supplier ID: " + supplierId;
    }
}

