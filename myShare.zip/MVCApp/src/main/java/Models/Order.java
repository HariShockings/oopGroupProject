package Models;

public class Order {
    private int orderId;
    private int customerId;
    private int productId;

    public Order(int customerId, int productId) {
        this.customerId = customerId;
        this.productId = productId;
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public int getCustomerId() {
        return customerId;
    }

    public int getProductId() {
        return productId;
    }

    @Override
    public String toString() {
        return "Order ID: " + orderId + ", Customer ID: " + customerId + ", Product Id: " + productId;
    }
}
