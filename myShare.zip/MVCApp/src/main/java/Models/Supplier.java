package Models;

public class Supplier {
    private int supplierId;
    private String supplierName;

    public Supplier(String supplierName) {
        this.supplierName = supplierName;
    }

    public Supplier(int supplierId, String supplierName) {
        this.supplierId = supplierId;
        this.supplierName = supplierName;
    }

    public int getSupplierId() {
        return supplierId;
    }

    public void getSupplierId(int supplierId) {
        this.supplierId = supplierId;
    }
    public void setSupplierId(int supplierId) {
        this.supplierId = supplierId;
    }

    public String getSupplierName() {
        return supplierName;
    }


    @Override
    public String toString() {
        return "Supplier ID: " + supplierId + ", Supplier Name: " + supplierName;
    }
}
